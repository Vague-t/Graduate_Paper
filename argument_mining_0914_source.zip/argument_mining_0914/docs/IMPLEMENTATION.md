# 实现协议与设计决策

状态：2026-09-14 新参考实现。论文历史实验可复现性为 CANNOT_VERIFY；下面是新代码的可执行选择，不是对旧实验事实的确认。

## 数据表示

统一文档包含 `id/source_id/split/corpus/text/tokens/token_offsets/sentences/graph`。评价 token 使用 Unicode 正则 `\w+|[^\w\s]`；原始标注是从 0 开始的半开字符区间，统一图使用从 1 开始的闭区间 token 坐标。它不同于 Qwen 的子词 token，必须分别记录。原始跨度无法精确对齐时拒绝；没有自动近似吸附、静默截断或以字符匹配替代 token 匹配。

AAEC BRAT 中 A/M 属性（含 stance）不转换为 Support/Attack；记录忽略计数。该关系表示下不允许 MajorClaim 成为关系端点。AAEC 不连续跨度尚不支持。CDCP 方言要求 `prop_offsets`、`prop_labels`、`reasons`、`evidences`；边的形式是 `[[source_lo, source_hi], target]`，组件索引从 0 开始。多前提默认 reject，可显式 expand；这不是合并跨度的复现。未知原始格式需要编写新适配器并测试，不应改数据直到现有脚本“能跑”为止。

推理前从文档删除 gold graph，只传 id/text/tokens。训练、数据统计和离线评价当然会读取金标准。源 ID 和完全重复文本的跨集检查不等于完整的数据污染审计。

## 类型条件模块

结构化监督固定序列顺序为 `id → type → span`。每个位置的门控只看已经可见的输出前缀；完整闭合 Claim/MajorClaim 类型字符串后，才在当前组件余下字段激活专项 LoRA。类型首 token 不提前开启；组件对象关闭后停止，relations 区域关闭。CDCP 的结论触发类型为 Policy/Value。教师强制只把可见前缀用于门控，不允许读到未来类型，也不会回溯修改已生成的跨度。

冻结骨干的每层 q_proj/v_proj 加全局 LoRA；Full 再加单独条件分支，均 r=16、alpha=32、dropout=0.05。全局 rank32、alpha64 对照匹配两条 rank16 分支的 LoRA 参数量；其他模块保持相同，但条件激活率和计算模式不同，不能宣称 FLOPs 精确一致。

Cue 词典：therefore / thus / in conclusion / consequently / hence / to conclude。不区分大小写，匹配词边界。出现线索时，在聊天模板 token 嵌入之前放 4 个连续提示向量；无触发时不放零向量占位。它不是离散提示词，也不是与金标准标签绑定的触发。

按 `[.!?。！？]` 及文本结尾做确定性句子切分，非语言学精细分句。训练输入中原文对应的最后一层 hidden states 做句内均值池化，再通过线性二分类头。与结论类 gold 跨度有任意重叠的句子为正；跨句组件使相关句子均为正。只池化输入原文区域，不池化输出 gold 标签区域。辅助头只训练时使用。

生成损失只对回答及 EOS 的有效 token 求每样本均值；句子 BCE 对输入句子求均值；总损失为两者按 1 和 0.5 加权。micro batch=1，累积 8 个任务样本（组件、关系或联合图任务各为一个样本），最后不足 8 个时按实际数量归一化。不是 8 篇文档，也不是全批 token 加权均值。默认 AdamW，固定 lr=2e-4，weight_decay=0.01，grad_norm=1，3 epochs，dev generation loss 早停 patience=2；这些未由历史记录确认。

## 候选与评分

single_pass：一次联合整图贪心生成。staged_k1：一次组件、一次固定组件的关系生成，均贪心。logprob/rerank/rerank_br：K=3，三个组件提示变体，temperature=0.7/top_p=0.9，逐个形成完整图。序列概率是两阶段生成 token 的原模型 log probability 总和除以总生成 token 数，含 EOS，不是组件置信度。

严格解析不修剪代码围栏、不接受重复 JSON 键、不静默消除重叠跨度、不重排 ID。关系阶段必须原样复制固定组件，否则该候选失败。可解析但有越界、重复或非法引用的图仍被保留并降低合法性评分。相同候选不自动去重，以便如实记录重复采样及成本。

连接覆盖评价 AAEC 的 Claim、CDCP 的 Policy/Value；不评价 AAEC MajorClaim。预测图中没有出边的评价节点视为顶层，阈值 2；其他阈值 1。有效且经语义验证器确认的入边计数除以阈值、截到 1，再对评价节点均值；空集合取 0。Attack 也计入论证连接，不是“支持证据”数量。该角色规则是新选择，不是恢复出的原算法。连贯性为边级布尔判断均值，空边集取 0。合法性是确定性检查的 0/1 指示；默认检查有向环，但不要求树或单父节点。原始 gold 环仅统计不自动删除，需要用真实语料判断约束是否相容。

默认权重依次 .4/.4/.2。移除分量时置零且不重新归一化，其他机制保留。因此 no_validity_score 只移除软评分，不移除硬动作接受检查；no_coherence 不自动取消密度计算所需的边判断。单纯移除评分项不能假定模型调用减少。

同一加载模型既生成也验证，使用不同提示；边级判断缓存绑定完整提示、文本和模型身份。无法解析为严格布尔值时显式失败，不当作正确或错误。评分是代理指标，不是人工真值。

## 四类修正与终止

- RemoveEdge：删除触发的关系，重评全图。
- Promote/Demote：仅 AAEC Claim/MajorClaim 互换；改类型后全图重检。CDCP 不套用这组标签动作。
- Replace：用候选池中与当前节点有跨度交叠的替代类型/边界，保留当前 ID 和节点数量。按交并比、位置、类型确定候选顺序；不实现 Insert。
- LocalRerun：节点不变，限制可输出的源节点，重新生成相关出边。低覆盖目标的潜在来源取其他节点；不是重新生成整篇图。

异常按严重度排序，同分 VAL→COH→DENS。每次接受后重算异常；最多 3 轮、每轮接受 2 次，总尝试 24 次、每异常最多 4 个动作候选。接受条件为全图合法且代理评分不降；记录已访问状态，避免相等分数来回震荡。两个独立非法引用不能逐个通过全图合法检查的问题有测试明确保留。

每文档所有生成和验证调用合计上限 128、输出 token 累计上限 32768，普通单调用上限 1024，边验证最多 32。失败调用仍计数，无法观测的输出工作量按分配上限保守计费并单列，不冒充实际 token 数。复用候选池仍占逻辑预算，实际缓存节省另列。输入 token 没有累计总上限，只有单次上下文上限；实现不承诺 GPU 驱动卡死等情况下的硬墙钟超时。

合法优先选项是单独变体，不是默认流程，也不保证无合法候选时输出合法。单步严格接受、没有 Insert 等局限不因存在该选项而消失。

## 评价与失败

组件键为 `(start,end,type)`；关系键由双方端点跨度、类型、方向、关系类型构成。默认包含端点类型；`--span-only-endpoints` 是另一个必须单列的协议。匹配不依赖预测 ID 是否与 gold ID 相同。重复预测按计数多重集累计，多余项为 FP，不由 set 去重提高分数。无效对象不能成为 TP；缺失、重复文档 ID 报错。显式失败预测为零个预测对象，gold 仍进入 FN。micro-F1 先合并对象计数再计算，空分母取 0，并报告所有允许类型。

跨域输出 AAEC 标签，不在生成时切换为 CDCP 细类型；预测 MajorClaim/Claim→Claim，Premise→Premise；gold Policy/Value→Claim，Fact/Testimony/Reference→Premise；关系都映射为有向 Link。默认粗类型也参与端点匹配。该设置没有使用目标标签示例，但源标签描述和源约束可能限制预测，这是显式协议选择。

候选 Oracle 函数仅提供按文档 Relation-F1 选候选的离线诊断，相同分数选最早候选；它不是语料级 micro-F1 的数学上界，也不实现原稿所有 Oracle 设置。不得将其进入在线推理。

## 增强与证据

训练集中的结论及其入邻居组成局部单位；MajorClaim 在 AAEC 当前图表示下可为单节点单位。新默认每文档最多 4 个单位、每单位 2 次尝试、最多保留 1 个变体。按原文位置作组件槽位替换，单位外文本不改；全文重新计算 token 坐标并更新所有受位移影响的组件，ID/类型/边不改。

先检查输出结构与槽位集合，再检查类型和拓扑保持，最后模型对原文和改写进行语义保持判断；局部拒绝和全局文本去重均记录。最终保留数量和混合比由实际输出统计，不是预设 1:1。未做人工语义审计。

外部技术依据只用于实现接口和模型使用说明：[Qwen 模型卡](https://huggingface.co/Qwen/Qwen2.5-7B-Instruct)、[Transformers 4.57 生成参数](https://huggingface.co/docs/transformers/v4.57.0/main_classes/text_generation)、[PEFT LoRA 参数说明](https://huggingface.co/docs/peft/main/package_reference/lora)、[Marseille 作者仓库](https://github.com/vene/marseille)。本项目条件分支为自定义 PyTorch 实现，没有使用 PEFT 的封装，也不声称复现 Marseille 的训练或预处理。
